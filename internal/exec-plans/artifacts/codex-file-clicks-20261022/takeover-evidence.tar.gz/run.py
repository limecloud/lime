import os, sys, subprocess, json, time
from pathlib import Path
root=Path("/Users/coso/Documents/dev/ai/aiclientproxy/lime")
e=root/"internal/exec-plans/artifacts/codex-file-clicks-20261022/takeover-r1"
name=sys.argv[1]; cmd=sys.argv[2:]; env=os.environ.copy()
env["PATH"]="/Users/coso/.local/share/rea/runtime/node-v24.21.0-darwin-arm64/bin:"+env["PATH"]
started=time.time()
with (e/(name+".log")).open("w") as log:
    process=subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
(e/(name+"-receipt.json")).write_text(json.dumps(dict(command=cmd,exitCode=process.returncode,durationSeconds=time.time()-started,cwd=str(root)),indent=2)+"\n")
print(name,"exit",process.returncode)
print((e/(name+".log")).read_text()[-4500:])
sys.exit(process.returncode)
