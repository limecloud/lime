import os, sys, subprocess, json, time
from pathlib import Path
root=Path("/Users/coso/Documents/dev/ai/aiclientproxy/lime")
e=root/"internal/exec-plans/artifacts/codex-file-clicks-20261022"
name=sys.argv[1]; cmd=sys.argv[2:]; env=os.environ.copy()
env["PATH"]="/Users/coso/.local/share/rea/runtime/node-v24.21.0-darwin-arm64/bin:"+env["PATH"]
t=time.time()
with (e/(name+".log")).open("w") as f:
 p=subprocess.run(cmd,cwd=root/".lime/verification/annotation-files-20261022-r2",env=env,stdout=f,stderr=subprocess.STDOUT)
(e/(name+"-receipt.json")).write_text(json.dumps(dict(command=cmd,exitCode=p.returncode,durationSeconds=time.time()-t),indent=2)+"\n")
print(name,"exit",p.returncode); print((e/(name+".log")).read_text()[-4500:])
sys.exit(p.returncode)
